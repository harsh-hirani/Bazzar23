<div id="chartContainer">
<div id="chartcontrols"></div>
    <div id="chartdiv"></div>
</div>

<div id="actions">
    <div class="buy-btn">
        <?php include 'buybtn.php'; ?>
    </div>
    <div class="sell-btn">
        <?php include 'sellbtn.php'; ?>
    </div>

</div>