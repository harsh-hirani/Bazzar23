<div>
    <h1 class="text-center fw-bolder my-4">QUERY</h1>
</div>
<div class=" form m-3">
    <div class="imgsvg">
        <img src="assets/undraw_real_time_analytics_re_yliv.svg" alt="">

    </div>
    <div class="mb-3 fw-bold content">

        <label for="exampleFormControlTextarea1" class="my-3 form-label">SEND YOUR QUERY :
        </label>
        <textarea class="my-4 form-control" id="exampleFormControlTextarea1" rows="7"
            placeholder="Enter your query here..."></textarea>
        <button class="send">
            <div class="svg-wrapper-1">
                <div class="svg-wrapper">
                    <svg height="24" width="24" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M0 0h24v24H0z" fill="none"></path>
                        <path
                            d="M1.946 9.315c-.522-.174-.527-.455.01-.634l19.087-6.362c.529-.176.832.12.684.638l-5.454 19.086c-.15.529-.455.547-.679.045L12 14l6-8-8 6-8.054-2.685z"
                            fill="currentColor"></path>
                    </svg>
                </div>
            </div>
            <span>SEND</span>
        </button>
    </div>


        </div>