<?php
setcookie("username", "name", time() + (86400 * 30), "/");
setcookie("userId", "1", time() + (86400 * 30), "/");

?>