<?php
include 'conn.php';
header('Content-Type: application/json');

?>